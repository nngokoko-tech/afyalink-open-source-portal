from datetime import datetime, date
from pathlib import Path
import sqlite3
from contextlib import contextmanager

from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "afyalink.db"

app = FastAPI(title="AfyaLink", description="Offline-friendly community health and stock tracking prototype")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
templates = Jinja2Templates(directory=ROOT / "templates")


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_code TEXT NOT NULL,
            age_months INTEGER NOT NULL,
            sex TEXT NOT NULL,
            symptoms TEXT NOT NULL,
            urgency TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS stock (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name TEXT NOT NULL UNIQUE,
            item_type TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 0,
            reorder_level INTEGER NOT NULL DEFAULT 10,
            updated_at TEXT NOT NULL
        )""")


@app.on_event("startup")
def startup():
    init_db()


def triage_guidance(age_months: int, symptoms: str) -> tuple[str, str]:
    """A conservative demo rule set, NOT a clinical diagnostic tool."""
    s = symptoms.lower()
    emergency_terms = [
        "difficulty breathing", "cannot breathe", "unconscious", "convulsion",
        "seizure", "blue lips", "severe bleeding", "not waking", "unable to drink"
    ]
    urgent_terms = [
        "high fever", "fever", "persistent vomiting", "blood in stool",
        "severe pain", "very weak", "dehydration"
    ]
    if any(term in s for term in emergency_terms):
        return "URGENT: immediate referral", (
            "This prototype detected a possible danger sign. Arrange immediate assessment/referral "
            "under local clinical protocols. Do not delay care to use this application."
        )
    if age_months < 2 and any(term in s for term in ["fever", "poor feeding", "not feeding", "lethargic"]):
        return "URGENT: immediate referral", (
            "Illness signs in a young infant can be serious. Arrange immediate assessment under local protocols."
        )
    if any(term in s for term in urgent_terms):
        return "Needs prompt clinical assessment", (
            "A symptom needing prompt assessment may be present. Follow approved local guidelines and consult a clinician."
        )
    return "No automated danger sign detected", (
        "This does not mean the patient is healthy. Assess using approved national guidelines, "
        "check for danger signs, and refer whenever concerned."
    )


@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    with db() as conn:
        patients = conn.execute("SELECT COUNT(*) AS n FROM patients").fetchone()["n"]
        items = conn.execute("SELECT COUNT(*) AS n FROM stock").fetchone()["n"]
        low = conn.execute("SELECT COUNT(*) AS n FROM stock WHERE quantity <= reorder_level").fetchone()["n"]
        recent = conn.execute("SELECT * FROM patients ORDER BY id DESC LIMIT 5").fetchall()
        low_items = conn.execute("SELECT * FROM stock WHERE quantity <= reorder_level ORDER BY quantity ASC").fetchall()
    return templates.TemplateResponse(request=request, name="index.html", context={
        "request": request, "patients": patients, "items": items, "low": low,
        "recent": recent, "low_items": low_items
    })


@app.get("/patients", response_class=HTMLResponse)
def patients_page(request: Request):
    with db() as conn:
        rows = conn.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
    return templates.TemplateResponse(request=request, name="patients.html", context={"request": request, "patients": rows})


@app.post("/patients")
def add_patient(
    patient_code: str = Form(...),
    age_months: int = Form(...),
    sex: str = Form(...),
    symptoms: str = Form(...),
    notes: str = Form("")
):
    patient_code = patient_code.strip()
    symptoms = symptoms.strip()
    if not patient_code or not symptoms or age_months < 0 or age_months > 240:
        raise HTTPException(status_code=400, detail="Please provide valid patient details.")
    urgency, guidance = triage_guidance(age_months, symptoms)
    with db() as conn:
        conn.execute(
            """INSERT INTO patients(patient_code, age_months, sex, symptoms, urgency, notes, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (patient_code, age_months, sex, symptoms, urgency, notes.strip(),
             datetime.now().isoformat(timespec="seconds"))
        )
    return RedirectResponse(url="/patients?added=1", status_code=303)


@app.get("/stock", response_class=HTMLResponse)
def stock_page(request: Request):
    with db() as conn:
        rows = conn.execute("SELECT * FROM stock ORDER BY item_name").fetchall()
    return templates.TemplateResponse(request=request, name="stock.html", context={"request": request, "items": rows})


@app.post("/stock")
def add_stock(
    item_name: str = Form(...),
    item_type: str = Form(...),
    quantity: int = Form(...),
    reorder_level: int = Form(...)
):
    name = item_name.strip()
    if not name or quantity < 0 or reorder_level < 0:
        raise HTTPException(status_code=400, detail="Enter a valid item name and non-negative quantities.")
    with db() as conn:
        conn.execute(
            """INSERT INTO stock(item_name, item_type, quantity, reorder_level, updated_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(item_name) DO UPDATE SET
               item_type=excluded.item_type, quantity=excluded.quantity,
               reorder_level=excluded.reorder_level, updated_at=excluded.updated_at""",
            (name, item_type, quantity, reorder_level, datetime.now().isoformat(timespec="seconds"))
        )
    return RedirectResponse(url="/stock?saved=1", status_code=303)


@app.get("/api/health")
def health():
    return {"status": "ok", "application": "AfyaLink prototype", "time": datetime.now().isoformat()}


@app.get("/manifest.json")
def manifest():
    return JSONResponse({
        "name": "AfyaLink Community Health",
        "short_name": "AfyaLink",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#f7faf9",
        "theme_color": "#126b5b",
        "icons": []
    })


@app.get("/service-worker.js")
def service_worker():
    js = """
const CACHE = 'afyalink-shell-v1';
const SHELL = ['/', '/patients', '/stock', '/static/style.css', '/static/app.js', '/manifest.json'];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(SHELL)));
  self.skipWaiting();
});
self.addEventListener('activate', event => {
  event.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;
  event.respondWith(
    fetch(event.request).then(response => {
      const copy = response.clone();
      caches.open(CACHE).then(cache => cache.put(event.request, copy));
      return response;
    }).catch(() => caches.match(event.request).then(cached => cached || caches.match('/')))
  );
});
"""
    from fastapi.responses import Response
    return Response(js, media_type="application/javascript")


app.mount("/assets", StaticFiles(directory=ROOT / "static"), name="assets")
