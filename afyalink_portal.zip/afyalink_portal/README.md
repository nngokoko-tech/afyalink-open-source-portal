# AfyaLink Open-Source Portal (Prototype)

AfyaLink is an early prototype for community health support and medicine/vaccine inventory monitoring in low-connectivity settings.

## Current status

**Prototype — not clinically validated and not ready for live patient data.** This repository is an initial demonstrator. It has a dashboard, local SQLite storage, patient assessment records with simple demonstration-only symptom rules, inventory tracking, low-stock alerts, a basic service-worker cache, and starter automated tests.

## Features

- Patient assessment record form using non-identifying codes.
- Demonstration-only symptom flags to encourage prompt clinical assessment.
- Medicine and vaccine stock entry/update and reorder-level alerts.
- SQLite database stored locally by the server.
- Basic progressive web app shell caching for some previously visited pages.
- Health-check endpoint at `/api/health`.

## Important limitations

- The triage rules are **not a medical device, diagnosis, or validated clinical protocol**. They can miss danger signs and must not be used for real clinical decisions.
- Offline support currently caches the app shell and previously fetched GET pages. **Creating new records while completely offline and synchronizing records between devices/servers are not implemented yet.**
- Authentication, role-based access, encryption at rest, audit logging, consent workflows, and secure deployment configuration are not implemented.
- Do not enter real patient-identifiable or confidential health data.
- Inventory alerts are based on a manually configured reorder level; predictive forecasting is not yet implemented.

## Run locally

Requires Python 3.10 or later.

### Windows (PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

If PowerShell blocks activation, use Command Prompt:

```bat
py -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

### Run tests

```bash
pytest
```

## Suggested next steps before a real pilot

1. Review all triage workflows with Tanzanian qualified clinicians and align them with approved national guidance.
2. Add authentication, permissions, audit logs, secure backups, and a threat/privacy assessment.
3. Implement and test true offline form submission and conflict-safe synchronization.
4. Validate inventory workflows with facility staff and define stock expiry/batch tracking.
5. Test usability, data quality, performance, and recovery from device loss/connectivity failures.
6. Obtain the required institutional, ethical, and regulatory approvals before using real patient data.

## License

Released under the MIT License. See `LICENSE`.

## Contribution

Bug reports and contributions are welcome. Please do not submit real patient information in issues or test data.
